package com.amazon.in.pages;

import com.amazon.in.base.TestBase;

public class BookSearch extends TestBase {

}
