package com.amazon.in.utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.amazon.in.base.TestBase;

public class TestUtil extends TestBase {
	public static long PAGE_LOAD_TIMEOUT=20;
	public static long IMPLICIT_WAIT=10;
	
	
	
	public static void mouseHover(WebElement element) {
		Actions action= new Actions(driver);
		action.moveToElement(element).build().perform();
	}

	public static void takeScreenshotAS() throws IOException {
		File src= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		String currentDir = System.getProperty("user.dir");
		FileUtils.copyFile(src, new File(currentDir+"/screenshots"+System.currentTimeMillis()+".png"));
	}
	
	
}
