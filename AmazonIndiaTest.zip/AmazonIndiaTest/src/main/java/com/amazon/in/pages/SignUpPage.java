package com.amazon.in.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.amazon.in.base.TestBase;

public class SignUpPage extends TestBase{
	
	
	@FindBy(xpath="//input[@id='ap_customer_name']")
	WebElement Yourname;
	
	@FindBy(xpath="//input[@id='ap_phone_number']")
	WebElement MobileNumber;
	
	@FindBy(xpath="//input[@id='ap_password1']")
	WebElement password;
	
	@FindBy(xpath="//input[@id='continue']")
	WebElement Continue;
	
	
	public SignUpPage() {
		PageFactory.initElements(driver, this);
	}
	
	public void enterdetails() {
		Yourname.sendKeys("Bikash");
		MobileNumber.sendKeys("7873155233");
		password.sendKeys("something");
	}
	
	

}
