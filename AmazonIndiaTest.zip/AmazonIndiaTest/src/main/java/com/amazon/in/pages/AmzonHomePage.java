package com.amazon.in.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.amazon.in.base.TestBase;
import com.amazon.in.utils.TestUtil;

public class AmzonHomePage extends TestBase{
	
	//Object Repositories
	
	@FindBy(xpath="//a[@id='nav-link-accountList']")
	WebElement signinbtn;
	
	@FindBy(xpath="//a[@id='nav-logo-sprites']")
	WebElement amazonLogoInHomePage;
	@FindBy(xpath="//a/span[text()='Sign in']")
	WebElement signin;

	@FindBy(xpath="//a[text()='Start here.']")
	WebElement newuser;
	//How to initialize the webelements is shown below
	//create a constructor and user PageFactory
	
	public AmzonHomePage() {
		PageFactory.initElements(driver, this);
	}
	
	
	//Actions
	
	public String validateTitle() {
		 return driver.getTitle();
		
	}
public boolean validateAmazonLogoInHomePage() {
	return amazonLogoInHomePage.isDisplayed();
}

public  SignUpPage checksigninButton() {
	TestUtil.mouseHover(signinbtn);
	boolean b=signin.isDisplayed();
	
	newuser.click();
	
	return new SignUpPage();
}




}
