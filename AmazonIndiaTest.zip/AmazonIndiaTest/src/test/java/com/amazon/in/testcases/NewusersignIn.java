package com.amazon.in.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.amazon.in.base.TestBase;
import com.amazon.in.pages.AmzonHomePage;
import com.amazon.in.pages.SignUpPage;

public class NewusersignIn extends TestBase {
	SignUpPage signup;
	NewusersignIn nsign;
	 public NewusersignIn() {
		 super();
	 }
	 
	 @BeforeMethod
	 public void setUp() {
		 initialization();
		 nsign=new NewusersignIn();
		 signup= new SignUpPage();
		 
	 }
	
	 @Test
	 public void signUp() {

		 AmzonHomePage a= new AmzonHomePage();
		String title= a.validateTitle();
		 if (title.equalsIgnoreCase("Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in")) {
			 System.out.println("correct title displayed");
		 }
		 //Assert.assertEquals(title,"");
		 a.checksigninButton();
		 signup.enterdetails();
		 
		 
	 }
	 
	
	 
	 
	 @AfterMethod
	 public void tearDown() {
		 driver.quit();
		 
	 }

}
